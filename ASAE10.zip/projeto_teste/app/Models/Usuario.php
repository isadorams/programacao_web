<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Categoria;
use App\Models\Venda;


class Usuario extends Model
{
    use HasFactory;
    protected $table = 'usuarios';

    function categoria(){
    	return $this->belongsTo(Categoria::class, 'id_categoria', 'id');
    }
     function venda(){
    	return $this->belongsTo(Categoria::class, 'id_venda', 'id');
    }
}
