<!DOCTYPE html>
<html>
<head>
 
  <!-- Required meta tags -->
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
	   <title>Cadastro</title>
</head>
<body>
<header>

  <nav class="navbar navbar-light bg-light">
  <div class="d-grid gap-2 d-md-block">
     <button type="button" class="btn btn-dark" type="submit">Novo Cadastro</button>
      <button type="button" class="btn btn-dark" type="submit">Já possuo Cadastro</button></div>
    <form class="d-flex">
      <input class="form-control me-2" type="search" placeholder="Search" aria-label="Pesquisar">
      <button type="button" class="btn btn-dark" type="submit">Pesquisar</button>
    </form>
  
</nav>
<br><br>

  <form action="a4.php" method="POST">
      <div class="d-grid gap-2 col-6 mx-auto">
        <label for="floatingInput">Nome de usuário:</label>
        <input type="text" name="usuario" class="form-control"  placeholder="Nome de usuário" id="usuario_id">
      </div>

      <div class="d-grid gap-2 col-6 mx-auto">
        <label for="floatingInput">Endereço do usuário:</label>
        <input type="text" name="endereco" class="form-control"  placeholder="Endereco do usuário" id="endereco_id">
      </div>

      <div class="d-grid gap-2 col-6 mx-auto">
        <label for="floatingInput">CEP:</label>
        <input type="number" name="cep" class="form-control"  placeholder="cep" id="cp_id">
      </div>

      <div class="d-grid gap-2 col-6 mx-auto">
        <label for="floatingInput">Cidade:</label>
        <input type="text" name="cidade" class="form-control"  placeholder="Cidade" id="cidade_id">
      </div>

      <div class="d-grid gap-2 col-6 mx-auto">
        <label for="floatingInput">Estado:</label>
            <select name="estados">
                <option value="bota">Acre-AC</option>
                <option value="fla">Alagoas-AL</option>
                <option value="flu">Amapá-AP</option>
                <option value="vasco">Amazonas-AM</option>
                <option value="bota">Bahia-BA</option>
                <option value="fla">Ceará-CE</option>
                <option value="flu">Distrito Federal-DF</option>
                <option value="vasco">Espírito Santo-ES</option>
                <option value="bota">Goiás-GO</option>
                <option value="fla">Maranhão-MA</option>
                <option value="flu">Mato Grosso-MT</option>
                <option value="vasco">Mato Grosso do Sul-MS</option>
                <option value="bota">Minas Gerais-MG</option>
                <option value="fla">Pará-PA</option>
                <option value="flu">Paraíba-PB</option>
                <option value="vasco">Paraná-PR</option>
                <option value="bota">Pernambuco-PE</option>
                <option value="fla">Piauí-PI</option>
                <option value="flu">Roraima-RR</option>
                <option value="vasco">Rondônia-RO</option>
                <option value="vasco">Rio de Janeiro-RJ</option>
                <option value="bota">Rio Grande do Norte-RN</option>
                <option value="fla">Rio Grande do Sul-RS</option>
                <option value="flu">Santa Catarina-SC</option>
                <option value="vasco">São Paulo-SP</option>
                <option value="vasco">Sergipe-SE</option>
                <option value="bota">Tocantins-TO</option>
            </select>
      </div>

      
      
     <br> <input type="submit" name="Entrar" class="d-grid gap-2 col-6 mx-auto btn btn-dark"/>
    </form>
    
</header>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
</body>
</html>