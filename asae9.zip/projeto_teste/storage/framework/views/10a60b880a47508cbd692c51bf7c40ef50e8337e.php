
<?php echo app('Tightenco\Ziggy\BladeRouteGenerator')->generate(); ?>
<?php $__env->startSection('conteudo'); ?>

    <h1 class="alert alert-<?php echo e($tipo_resposta); ?>"><?php echo e($resposta); ?></h1>

    <?php if(session('mensagem')): ?>
    <div class="alert-alert-success">
      <?php echo e(session('mensagem')); ?>

    </div>
    <?php endif; ?>

    <?php if($tipo_resposta == 'success'): ?>
    <table class="table">
      <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Endereço</th>
        <th>CEP</th>
        <th>Cidade</th>
        <th>Estado</th>
        <th>Email</th>
        <th>Categoria</th>
        <th>Operações</th>
      </tr>
       <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($u->id); ?></td>
        <td><?php echo e($u->nome); ?></td>
        <td><?php echo e($u->endereco); ?></td>
        <td><?php echo e($u->cep); ?></td>
        <td><?php echo e($u->cidade); ?></td>
        <td><?php echo e($u->estado); ?></td>
        <td><?php echo e($u->email); ?></td>
        <td><?php echo e($u->categoria->nome); ?></td>
        <td> 
          <a href="<?php echo e(route('usuario_editar', ['id' => $u->id])); ?>" class="btn btn-warning">Alterar</a>

          <a href="#" onclick="excluir(<?php echo e($u->id); ?>)" class="btn btn-danger">Excluir</a>
         </td>
       </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php endif; ?>
    <a href="<?php echo e(route('usuario_novo')); ?>" class="btn btn-success">Adicionar novo</a><br>
    <a href="#" class="btn btn-danger mt-5">Logout</a>

    <script type="text/javascript">
      function excluir(id){
        if(confirm('Voce deseja excluir realmente o usuario de id: ' + id + '?')){
          location.href = route('usuario_excluir', { id: id });
        }
      }
    </script>
    
  <?php $__env->stopSection(); ?> 
<?php echo $__env->make('templates', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projeto_teste\resources\views/retornologin.blade.php ENDPATH**/ ?>