<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UsuarioController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/login', [UsuarioController::class, 'exibeLogin'])->name('login');
Route::post('/tenta_login', [UsuarioController::class, 'tentaLogin']);


Route::get('/usuario/novo', [UsuarioController::class, 'novo'])->name('usuario_novo');
Route::post('/usuario/inserir', [UsuarioController::class, 'inserir'])->name('usuario_inserir');

Route::get('/usuario/editar/{id}', [UsuarioController::class, 'editar'])->name('usuario_editar');
Route::post('/usuario/alterar/{id}', [UsuarioController::class, 'alterar'])->name('usuario_alterar');

Route::get('/usuario/excluir/{id}', [UsuarioController::class, 'excluir'])->name('usuario_excluir');


Route::get('/usuario/lista', [UsuarioController::class, 'tela_principal'])->name('usuario_lista');

Route::get('/usuario/logout', [UsuarioController::class, 'logout'])->name('logout');
