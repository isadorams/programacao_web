@extends('templates')

@section('conteudo')

<nav class="navbar navbar-light bg-light">
	  <div class="d-grid gap-2 d-md-block">
	     <button type="button" class="btn btn-dark" type="submit">Novo Cadastro</button>
	      <button type="button" class="btn btn-dark" type="submit">Já possuo Cadastro</button></div>
	    <form class="d-flex">
	      <input class="form-control me-2" type="search" placeholder="Search" aria-label="Pesquisar">
	      <button type="button" class="btn btn-dark" type="submit">Pesquisar</button>
	    </form>
	</nav>
	<br>

	<div class="alert alert-secondary" role="alert">
	 <h2>Novo Usuário</h2>
	</div>



<form method="POST" action="{{ route('usuario_inserir')}}">
	@csrf
	<div class="d-grid gap-2 col-6 mx-auto">
	  <label for="floatingInput">Nome de usuário:</label>
	  <input type="text" name="nome" class="form-control"  placeholder="Nome de usuário" name="nome" id="usuario_id">
	</div>

	<div class="d-grid gap-2 col-6 mx-auto">
	  <label for="floatingInput">Endereço do usuário:</label>
	  <input type="text" name="endereco" class="form-control"  placeholder="Endereco do usuário"  name="endereco" id="endereco_id">
	</div>

	<div class="d-grid gap-2 col-6 mx-auto">
	  <label for="floatingInput">CEP:</label>
	  <input  type="tel" name="cep" class="form-control"  placeholder="cep"  name="cpf" id="cp_id">
	</div>

	<div class="d-grid gap-2 col-6 mx-auto">
	  <label for="floatingInput">Cidade:</label>
	  <input type="text" name="cidade" class="form-control"  placeholder="Cidade"  name="cidade" id="cidade_id">
	</div>

	<div class="d-grid gap-2 col-6 mx-auto">
	  <label for="floatingInput">Estado:</label>
	      <select  type="text" class="form-control"  placeholder="Estados"  name="estado" id="estados_id">
	          <option value="bota">Acre-AC</option>
	          <option value="fla">Alagoas-AL</option>
	          <option value="flu">Amapá-AP</option>
	          <option value="vasco">Amazonas-AM</option>
	          <option value="bota">Bahia-BA</option>
	          <option value="fla">Ceará-CE</option>
	          <option value="flu">Distrito Federal-DF</option>
	          <option value="vasco">Espírito Santo-ES</option>
	          <option value="bota">Goiás-GO</option>
	          <option value="fla">Maranhão-MA</option>
	          <option value="flu">Mato Grosso-MT</option>
	          <option value="vasco">Mato Grosso do Sul-MS</option>
	          <option value="bota">Minas Gerais-MG</option>
	          <option value="fla">Pará-PA</option>
	          <option value="flu">Paraíba-PB</option>
	          <option value="vasco">Paraná-PR</option>
	          <option value="bota">Pernambuco-PE</option>
	          <option value="fla">Piauí-PI</option>
	          <option value="flu">Roraima-RR</option>
	          <option value="vasco">Rondônia-RO</option>
	          <option value="vasco">Rio de Janeiro-RJ</option>
	          <option value="bota">Rio Grande do Norte-RN</option>
	          <option value="fla">Rio Grande do Sul-RS</option>
	          <option value="flu">Santa Catarina-SC</option>
	          <option value="vasco">São Paulo-SP</option>
	          <option value="vasco">Sergipe-SE</option>
	          <option value="bota">Tocantins-TO</option>
	      </select>
	</div>
	
	<div class="d-grid gap-2 col-6 mx-auto">
		<label for="f_email">Email</label>
	   <input type="email" class="form-control" id="f_email" placeholder="name@example.com" name="email">
	</div>
	
	<div class="d-grid gap-2 col-6 mx-auto">
	<label for="f_senha">Senha</label>
	 <input type="password" class="form-control" id="f_senha" placeholder="Senha" name="senha">
	</div>
	<input type="submit" class="btn btn-dark"  value="Cadastrar">
</form>
@endsection('conteudo')